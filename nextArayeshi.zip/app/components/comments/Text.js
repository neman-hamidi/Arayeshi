const commentsUser = [
  {
    src: "/me/images/24.png",
    name: "سارا محمدی",
    title: "طرفدار محصولات شیگلم",
  },
  {
    src: "/me/images/25.png",
    name: "مهتاب کرامتی",
    title: " طرفدار محصولات شیگلم",
  },
  {
    src: "/me/images/26.png",
    name: "آتنا عصار",
    title: "طرفدار محصولات شیگلم",
  },
  {
    src: "/me/images/27.png",
    name: "مبینا اکبری",
    title: "طرفدار محصولات شیگلم",
  },
];

export default commentsUser;
