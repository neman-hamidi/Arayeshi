const btns = [
  { title: "اوردینری" },
  { title: "شیگلم" },
  { title: "ویکتوریا سیکرت" },
  { title: "جان استونز" },
  { title: "لطیفه" },
  { title: "سرا-وِ" },
  { title: "وانتدگرل" },
];
export default btns;
