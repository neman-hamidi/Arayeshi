const details = [
  { title: "لوسیون بدن", count: "24", src: "/me/images/Frame-19.png" },
  { title: "کرم مراقبت از پوست", count: "34", src: "/me/images/Frame-20.png" },
  { title: "ضد جوش و لکه بر", count: "19", src: "/me/images/Frame-21.png" },
  { title: "آبرسان پوست", count: "8", src: "/me/images/Frame-22.png" },
];

export default details;
