const btns = [
  " همه محصولات",
  " اوردینری",
  " شیگلم",
  " ویکتوریا سیکرت",
  " جان استونز",
];
const details = [
  { title: "تمیز کننده پوست", price: "750,000", src: "/me/images/best6.png" },
  { title: "اوردینری", price: "58,000", src: "/me/images/best2.png" },
  { title: "شفاف کننده", price: "750,000", src: "/me/images/best3.png" },
  { title: "شیگلم", price: "300,000", src: "/me/images/best4.png" },
  { title: "استونز", price: "12,000", src: "/me/images/best5.png" },
  { title: "ضدجوش و لکه بر", price: "90,000", src: "/me/images/best6.png" },
  { title: "لایه بر پوست", price: "340,000", src: "/me/images/best7.png" },
  { title: "ضدجوش و لکه بر", price: "100,000", src: "/me/images/best8.png" },
];
export { btns, details };
